# chat-room
a simple chat room used by python websocket

step 1:<br />
start websocket server,go to the server dir<br />
python chatserver.py start<br />

step2:<br />
go to the client dir,use Browser to open the chat_view.html<br />
first set your name<br />
your can send messages to chat.<br />
